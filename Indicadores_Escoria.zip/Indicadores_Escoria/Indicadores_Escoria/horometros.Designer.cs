﻿namespace Indicadores_Escoria
{
    partial class horometros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            tableLayoutPanel2 = new TableLayoutPanel();
            label1 = new Label();
            panel2 = new Panel();
            tableLayoutPanel1 = new TableLayoutPanel();
            label2 = new Label();
            label3 = new Label();
            cmbmes = new ComboBox();
            cmbanio = new ComboBox();
            label4 = new Label();
            panel5 = new Panel();
            iconButton1 = new FontAwesome.Sharp.IconButton();
            panel3 = new Panel();
            tableLayoutPanel3 = new TableLayoutPanel();
            Fuera_operación = new FontAwesome.Sharp.IconButton();
            label5 = new Label();
            Sin_horometro = new FontAwesome.Sharp.IconButton();
            Operando = new FontAwesome.Sharp.IconButton();
            Disponible = new FontAwesome.Sharp.IconButton();
            panelMotivo = new Panel();
            motivo = new TextBox();
            lblMotivo = new Label();
            panel4 = new Panel();
            tabla_horometros = new DataGridView();
            panel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            panel2.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            panel5.SuspendLayout();
            panel3.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            panelMotivo.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)tabla_horometros).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(tableLayoutPanel2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1424, 40);
            panel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(label1, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 0);
            tableLayoutPanel2.Margin = new Padding(0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(1424, 40);
            tableLayoutPanel2.TabIndex = 0;
            tableLayoutPanel2.Paint += tableLayoutPanel2_Paint;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(555, 9);
            label1.Name = "label1";
            label1.Size = new Size(314, 22);
            label1.TabIndex = 0;
            label1.Text = "Registro mensual de horómetros";
            label1.Click += label1_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(tableLayoutPanel1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 40);
            panel2.Name = "panel2";
            panel2.Size = new Size(1424, 79);
            panel2.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 6;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 6.10876846F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 6.108769F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.0003929F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 6.11017132F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.0003929F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 53.67151F));
            tableLayoutPanel1.Controls.Add(label2, 0, 0);
            tableLayoutPanel1.Controls.Add(label3, 1, 0);
            tableLayoutPanel1.Controls.Add(cmbmes, 2, 0);
            tableLayoutPanel1.Controls.Add(cmbanio, 4, 0);
            tableLayoutPanel1.Controls.Add(label4, 3, 0);
            tableLayoutPanel1.Controls.Add(panel5, 5, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Margin = new Padding(0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(1424, 79);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            label2.Location = new Point(5, 28);
            label2.Margin = new Padding(0);
            label2.Name = "label2";
            label2.Size = new Size(76, 22);
            label2.TabIndex = 0;
            label2.Text = "Filtros:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12.75F);
            label3.Location = new Point(107, 30);
            label3.Name = "label3";
            label3.Size = new Size(44, 19);
            label3.TabIndex = 1;
            label3.Text = "Mes:";
            // 
            // cmbmes
            // 
            cmbmes.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            cmbmes.Font = new Font("Arial", 12.75F);
            cmbmes.FormattingEnabled = true;
            cmbmes.Location = new Point(175, 26);
            cmbmes.Name = "cmbmes";
            cmbmes.Size = new Size(193, 27);
            cmbmes.TabIndex = 2;
            // 
            // cmbanio
            // 
            cmbanio.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            cmbanio.Font = new Font("Arial", 12.75F);
            cmbanio.FormattingEnabled = true;
            cmbanio.Location = new Point(461, 26);
            cmbanio.Name = "cmbanio";
            cmbanio.Size = new Size(193, 27);
            cmbanio.TabIndex = 3;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12.75F);
            label4.Location = new Point(393, 30);
            label4.Name = "label4";
            label4.Size = new Size(43, 19);
            label4.TabIndex = 4;
            label4.Text = "Año:";
            // 
            // panel5
            // 
            panel5.Controls.Add(iconButton1);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(657, 0);
            panel5.Margin = new Padding(0);
            panel5.Name = "panel5";
            panel5.Size = new Size(767, 79);
            panel5.TabIndex = 5;
            // 
            // iconButton1
            // 
            iconButton1.Anchor = AnchorStyles.Right;
            iconButton1.BackgroundImageLayout = ImageLayout.None;
            iconButton1.Font = new Font("Arial", 12.75F);
            iconButton1.IconChar = FontAwesome.Sharp.IconChar.FileArrowDown;
            iconButton1.IconColor = Color.Green;
            iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButton1.IconSize = 30;
            iconButton1.Location = new Point(627, 0);
            iconButton1.Name = "iconButton1";
            iconButton1.Size = new Size(128, 40);
            iconButton1.TabIndex = 5;
            iconButton1.Text = "Exportar";
            iconButton1.TextImageRelation = TextImageRelation.ImageBeforeText;
            iconButton1.UseVisualStyleBackColor = true;
            iconButton1.Click += iconButton1_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(tableLayoutPanel3);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 119);
            panel3.Margin = new Padding(0);
            panel3.Name = "panel3";
            panel3.Size = new Size(1424, 112);
            panel3.TabIndex = 2;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 6;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 7.834165F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.9092369F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.9092369F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.9092369F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.9092369F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 24.5288925F));
            tableLayoutPanel3.Controls.Add(Fuera_operación, 4, 0);
            tableLayoutPanel3.Controls.Add(label5, 0, 0);
            tableLayoutPanel3.Controls.Add(Sin_horometro, 3, 0);
            tableLayoutPanel3.Controls.Add(Operando, 1, 0);
            tableLayoutPanel3.Controls.Add(Disponible, 2, 0);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(0, 0);
            tableLayoutPanel3.Margin = new Padding(0);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.Size = new Size(1424, 112);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // Fuera_operación
            // 
            Fuera_operación.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            Fuera_operación.Font = new Font("Arial", 12.75F);
            Fuera_operación.ForeColor = Color.Red;
            Fuera_operación.IconChar = FontAwesome.Sharp.IconChar.CircleDot;
            Fuera_operación.IconColor = Color.Red;
            Fuera_operación.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Fuera_operación.Location = new Point(834, 21);
            Fuera_operación.Name = "Fuera_operación";
            Fuera_operación.Size = new Size(234, 70);
            Fuera_operación.TabIndex = 5;
            Fuera_operación.Text = "Fuera de operación";
            Fuera_operación.TextImageRelation = TextImageRelation.ImageBeforeText;
            Fuera_operación.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            label5.Location = new Point(14, 45);
            label5.Name = "label5";
            label5.Size = new Size(82, 22);
            label5.TabIndex = 4;
            label5.Text = "Estado:";
            // 
            // Sin_horometro
            // 
            Sin_horometro.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            Sin_horometro.Font = new Font("Arial", 12.75F);
            Sin_horometro.ForeColor = Color.LimeGreen;
            Sin_horometro.IconChar = FontAwesome.Sharp.IconChar.CircleDot;
            Sin_horometro.IconColor = Color.LimeGreen;
            Sin_horometro.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Sin_horometro.Location = new Point(594, 21);
            Sin_horometro.Name = "Sin_horometro";
            Sin_horometro.Size = new Size(234, 70);
            Sin_horometro.TabIndex = 2;
            Sin_horometro.Text = "Sin horómetro";
            Sin_horometro.TextImageRelation = TextImageRelation.ImageBeforeText;
            Sin_horometro.UseVisualStyleBackColor = true;
            // 
            // Operando
            // 
            Operando.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            Operando.Font = new Font("Arial", 12.75F);
            Operando.IconChar = FontAwesome.Sharp.IconChar.CircleDot;
            Operando.IconColor = Color.Black;
            Operando.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Operando.Location = new Point(114, 21);
            Operando.Name = "Operando";
            Operando.Size = new Size(234, 70);
            Operando.TabIndex = 0;
            Operando.Text = "Operando";
            Operando.TextImageRelation = TextImageRelation.ImageBeforeText;
            Operando.UseVisualStyleBackColor = true;
            // 
            // Disponible
            // 
            Disponible.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            Disponible.Font = new Font("Arial", 12.75F);
            Disponible.ForeColor = Color.DeepSkyBlue;
            Disponible.IconChar = FontAwesome.Sharp.IconChar.CircleDot;
            Disponible.IconColor = Color.DeepSkyBlue;
            Disponible.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Disponible.Location = new Point(354, 21);
            Disponible.Name = "Disponible";
            Disponible.Size = new Size(234, 70);
            Disponible.TabIndex = 1;
            Disponible.Text = "Disponible";
            Disponible.TextImageRelation = TextImageRelation.ImageBeforeText;
            Disponible.UseVisualStyleBackColor = true;
            // 
            // panelMotivo
            // 
            panelMotivo.BackColor = SystemColors.ControlLightLight;
            panelMotivo.Controls.Add(motivo);
            panelMotivo.Controls.Add(lblMotivo);
            panelMotivo.Dock = DockStyle.Top;
            panelMotivo.Location = new Point(0, 231);
            panelMotivo.Margin = new Padding(0);
            panelMotivo.Name = "panelMotivo";
            panelMotivo.Padding = new Padding(0, 10, 0, 10);
            panelMotivo.Size = new Size(1424, 80);
            panelMotivo.TabIndex = 3;
            // 
            // motivo
            // 
            motivo.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            motivo.BackColor = Color.White;
            motivo.Enabled = false;
            motivo.Font = new Font("Arial", 11F);
            motivo.Location = new Point(130, 12);
            motivo.MaxLength = 200;
            motivo.Multiline = true;
            motivo.Name = "motivo";
            motivo.PlaceholderText = "Seleccione una fecha; la observación se guarda automáticamente al salir del cuadro...";
            motivo.ScrollBars = ScrollBars.Vertical;
            motivo.Size = new Size(1054, 55);
            motivo.TabIndex = 1;
            // 
            // lblMotivo
            // 
            lblMotivo.AutoSize = true;
            lblMotivo.Font = new Font("Arial", 12.75F, FontStyle.Bold);
            lblMotivo.Location = new Point(12, 29);
            lblMotivo.Name = "lblMotivo";
            lblMotivo.Size = new Size(114, 19);
            lblMotivo.TabIndex = 0;
            lblMotivo.Text = "Observación:";
            // 
            // panel4
            // 
            panel4.Controls.Add(tabla_horometros);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(0, 311);
            panel4.Margin = new Padding(0);
            panel4.Name = "panel4";
            panel4.Size = new Size(1424, 670);
            panel4.TabIndex = 4;
            // 
            // tabla_horometros
            // 
            tabla_horometros.BackgroundColor = SystemColors.ControlLightLight;
            tabla_horometros.BorderStyle = BorderStyle.None;
            tabla_horometros.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tabla_horometros.Dock = DockStyle.Fill;
            tabla_horometros.Location = new Point(0, 0);
            tabla_horometros.Margin = new Padding(0);
            tabla_horometros.Name = "tabla_horometros";
            tabla_horometros.Size = new Size(1424, 670);
            tabla_horometros.TabIndex = 0;
            // 
            // horometros
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1424, 981);
            Controls.Add(panel4);
            Controls.Add(panelMotivo);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "horometros";
            Text = "Horómetros";
            Load += horometros_Load;
            panel1.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            panel2.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            panel5.ResumeLayout(false);
            panel3.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            panelMotivo.ResumeLayout(false);
            panelMotivo.PerformLayout();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)tabla_horometros).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label2;
        private Label label3;
        private ComboBox cmbmes;
        private ComboBox cmbanio;
        private Label label4;
        private FontAwesome.Sharp.IconButton iconButton1;
        private TableLayoutPanel tableLayoutPanel2;
        private Label label5;
        private FontAwesome.Sharp.IconButton Sin_horometro;
        private FontAwesome.Sharp.IconButton Disponible;
        private FontAwesome.Sharp.IconButton Operando;
        private TableLayoutPanel tableLayoutPanel3;
        private DataGridView tabla_horometros;
        private Panel panel5;
        private FontAwesome.Sharp.IconButton Fuera_operación;
        private Panel panelMotivo;
        private Label lblMotivo;
        private TextBox motivo;
    }
}
