﻿namespace Indicadores_Escoria
{
    partial class equipos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            panelpantalla = new Panel();
            paneldatos = new Panel();
            tablaEquipos = new DataGridView();
            paneldatosxd = new Panel();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel2 = new TableLayoutPanel();
            panel7 = new Panel();
            label7 = new Label();
            txtcliente = new TextBox();
            panel5 = new Panel();
            label3 = new Label();
            txtproyecto = new TextBox();
            panel3 = new Panel();
            label6 = new Label();
            txtmodelo = new TextBox();
            panelEco = new Panel();
            lblEco = new Label();
            txtEco = new TextBox();
            panel1 = new Panel();
            label2 = new Label();
            txtserie = new TextBox();
            panel2 = new Panel();
            label4 = new Label();
            txttipoequipo = new TextBox();
            panel6 = new Panel();
            label5 = new Label();
            txtpropiedad = new TextBox();
            panel8 = new Panel();
            iconButton1 = new FontAwesome.Sharp.IconButton();
            iconButton2 = new FontAwesome.Sharp.IconButton();
            iconButton3 = new FontAwesome.Sharp.IconButton();
            iconButton4 = new FontAwesome.Sharp.IconButton();
            tableLayoutPanelkpis = new TableLayoutPanel();
            tableLayoutPanel4 = new TableLayoutPanel();
            panel4 = new Panel();
            tableLayoutPanel3 = new TableLayoutPanel();
            label10 = new Label();
            buscarEco = new TextBox();
            label11 = new Label();
            paneltitulo = new Panel();
            label8 = new Label();
            label9 = new Label();
            panelpantalla.SuspendLayout();
            paneldatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)tablaEquipos).BeginInit();
            paneldatosxd.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            panel7.SuspendLayout();
            panel5.SuspendLayout();
            panel3.SuspendLayout();
            panelEco.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel6.SuspendLayout();
            panel8.SuspendLayout();
            tableLayoutPanelkpis.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            panel4.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            paneltitulo.SuspendLayout();
            SuspendLayout();
            // 
            // panelpantalla
            // 
            panelpantalla.Controls.Add(paneldatos);
            panelpantalla.Controls.Add(paneltitulo);
            panelpantalla.Dock = DockStyle.Fill;
            panelpantalla.Location = new Point(0, 0);
            panelpantalla.Margin = new Padding(0);
            panelpantalla.Name = "panelpantalla";
            panelpantalla.Padding = new Padding(20);
            panelpantalla.Size = new Size(2164, 1410);
            panelpantalla.TabIndex = 0;
            // 
            // paneldatos
            // 
            paneldatos.Controls.Add(paneldatosxd);
            paneldatos.Controls.Add(panel4);
            paneldatos.Dock = DockStyle.Fill;
            paneldatos.Location = new Point(20, 88);
            paneldatos.Margin = new Padding(0);
            paneldatos.Name = "paneldatos";
            paneldatos.Size = new Size(2124, 1302);
            paneldatos.TabIndex = 3;
            // 
            // panelRedondeadotabla
            // 
            // tablaEquipos
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(242, 247, 253);
            tablaEquipos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            tablaEquipos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tablaEquipos.BackgroundColor = Color.White;
            tablaEquipos.BorderStyle = BorderStyle.None;
            tablaEquipos.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.ActiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = Color.Black;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            tablaEquipos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            tablaEquipos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tablaEquipos.Cursor = Cursors.Hand;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = Color.SteelBlue;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            tablaEquipos.DefaultCellStyle = dataGridViewCellStyle3;
            tablaEquipos.Dock = DockStyle.Fill;
            tablaEquipos.EnableHeadersVisualStyles = false;
            tablaEquipos.GridColor = SystemColors.ScrollBar;
            tablaEquipos.Location = new Point(0, 0);
            tablaEquipos.Margin = new Padding(0);
            tablaEquipos.MultiSelect = false;
            tablaEquipos.Name = "tablaEquipos";
            tablaEquipos.ReadOnly = true;
            tablaEquipos.RightToLeft = RightToLeft.No;
            tablaEquipos.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Arial", 12F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.SteelBlue;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            tablaEquipos.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            tablaEquipos.RowHeadersVisible = false;
            tablaEquipos.RowHeadersWidth = 62;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tablaEquipos.RowsDefaultCellStyle = dataGridViewCellStyle5;
            tablaEquipos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tablaEquipos.Size = new Size(2124, 929);
            tablaEquipos.TabIndex = 0;
            tablaEquipos.CellClick += tablaEquipos_CellClick;
            // 
            // paneldatosxd
            // 
            paneldatosxd.BackColor = Color.Transparent;
            paneldatosxd.Controls.Add(tableLayoutPanel1);
            paneldatosxd.Dock = DockStyle.Top;
            paneldatosxd.Location = new Point(0, 93);
            paneldatosxd.Margin = new Padding(0);
            paneldatosxd.Name = "paneldatosxd";
            paneldatosxd.Padding = new Padding(0, 0, 0, 20);
            paneldatosxd.Size = new Size(2124, 280);
            paneldatosxd.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Transparent;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 51.8489075F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 0.437375754F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 47.71372F));
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Margin = new Padding(0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(2124, 260);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // panelRedondeado1
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.BackColor = Color.FromArgb(0, 15, 255, 255);
            tableLayoutPanel2.ColumnCount = 3;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33333F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            tableLayoutPanel2.Controls.Add(panel7, 0, 2);
            tableLayoutPanel2.Controls.Add(panel5, 1, 1);
            tableLayoutPanel2.Controls.Add(panel3, 0, 1);
            tableLayoutPanel2.Controls.Add(panelEco, 0, 0);
            tableLayoutPanel2.Controls.Add(panel1, 1, 0);
            tableLayoutPanel2.Controls.Add(panel2, 1, 2);
            tableLayoutPanel2.Controls.Add(panel6, 2, 0);
            tableLayoutPanel2.Controls.Add(panel8, 2, 1);
            tableLayoutPanel2.Cursor = Cursors.Hand;
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.ForeColor = Color.White;
            tableLayoutPanel2.GrowStyle = TableLayoutPanelGrowStyle.FixedSize;
            tableLayoutPanel2.Location = new Point(10, 10);
            tableLayoutPanel2.Margin = new Padding(0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 3;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel2.Size = new Size(1081, 240);
            tableLayoutPanel2.TabIndex = 3;
            tableLayoutPanel2.Paint += tableLayoutPanel2_Paint;
            // 
            // panel7
            // 
            panel7.Controls.Add(label7);
            panel7.Controls.Add(txtcliente);
            panel7.Dock = DockStyle.Fill;
            panel7.Location = new Point(0, 160);
            panel7.Margin = new Padding(0);
            panel7.Name = "panel7";
            panel7.Size = new Size(360, 80);
            panel7.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Dock = DockStyle.Bottom;
            label7.Font = new Font("Arial", 12F);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(0, 18);
            label7.Margin = new Padding(17, 0, 0, 0);
            label7.Name = "label7";
            label7.Size = new Size(87, 27);
            label7.TabIndex = 6;
            label7.Text = "Cliente";
            // 
            // txtcliente
            // 
            txtcliente.BackColor = Color.FromArgb(242, 247, 253);
            txtcliente.BorderStyle = BorderStyle.FixedSingle;
            txtcliente.Cursor = Cursors.IBeam;
            txtcliente.Dock = DockStyle.Bottom;
            txtcliente.Font = new Font("Arial", 12F);
            txtcliente.ForeColor = SystemColors.MenuText;
            txtcliente.Location = new Point(0, 45);
            txtcliente.Margin = new Padding(6, 0, 37, 0);
            txtcliente.Name = "txtcliente";
            txtcliente.Size = new Size(360, 35);
            txtcliente.TabIndex = 12;
            txtcliente.TextAlign = HorizontalAlignment.Center;
            // 
            // panel5
            // 
            panel5.Controls.Add(label3);
            panel5.Controls.Add(txtproyecto);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(360, 80);
            panel5.Margin = new Padding(0);
            panel5.Name = "panel5";
            panel5.Size = new Size(360, 80);
            panel5.TabIndex = 30;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Bottom;
            label3.Font = new Font("Arial", 12F);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(0, 18);
            label3.Margin = new Padding(17, 0, 0, 0);
            label3.Name = "label3";
            label3.Size = new Size(106, 27);
            label3.TabIndex = 2;
            label3.Text = "Proyecto";
            // 
            // txtproyecto
            // 
            txtproyecto.BackColor = Color.FromArgb(242, 247, 253);
            txtproyecto.BorderStyle = BorderStyle.FixedSingle;
            txtproyecto.Cursor = Cursors.IBeam;
            txtproyecto.Dock = DockStyle.Bottom;
            txtproyecto.Font = new Font("Arial", 12F);
            txtproyecto.ForeColor = SystemColors.MenuText;
            txtproyecto.Location = new Point(0, 45);
            txtproyecto.Margin = new Padding(6, 0, 37, 0);
            txtproyecto.Name = "txtproyecto";
            txtproyecto.Size = new Size(360, 35);
            txtproyecto.TabIndex = 11;
            txtproyecto.TextAlign = HorizontalAlignment.Center;
            // 
            // panel3
            // 
            panel3.Controls.Add(label6);
            panel3.Controls.Add(txtmodelo);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 80);
            panel3.Margin = new Padding(0);
            panel3.Name = "panel3";
            panel3.Size = new Size(360, 80);
            panel3.TabIndex = 29;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Dock = DockStyle.Bottom;
            label6.Font = new Font("Arial", 12F);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(0, 18);
            label6.Margin = new Padding(17, 0, 0, 0);
            label6.Name = "label6";
            label6.Size = new Size(90, 27);
            label6.TabIndex = 5;
            label6.Text = "Modelo";
            label6.Click += label6_Click;
            // 
            // txtmodelo
            // 
            txtmodelo.BackColor = Color.FromArgb(242, 247, 253);
            txtmodelo.BorderStyle = BorderStyle.FixedSingle;
            txtmodelo.Cursor = Cursors.IBeam;
            txtmodelo.Dock = DockStyle.Bottom;
            txtmodelo.Font = new Font("Arial", 12F);
            txtmodelo.ForeColor = SystemColors.MenuText;
            txtmodelo.Location = new Point(0, 45);
            txtmodelo.Margin = new Padding(6, 0, 37, 0);
            txtmodelo.Name = "txtmodelo";
            txtmodelo.Size = new Size(360, 35);
            txtmodelo.TabIndex = 10;
            txtmodelo.TextAlign = HorizontalAlignment.Center;
            // 
            // panelEco
            // 
            panelEco.Controls.Add(lblEco);
            panelEco.Controls.Add(txtEco);
            panelEco.Dock = DockStyle.Fill;
            panelEco.Location = new Point(0, 0);
            panelEco.Margin = new Padding(0);
            panelEco.Name = "panelEco";
            panelEco.Size = new Size(360, 80);
            panelEco.TabIndex = 26;
            // 
            // lblEco
            // 
            lblEco.AutoSize = true;
            lblEco.BackColor = Color.Transparent;
            lblEco.Dock = DockStyle.Bottom;
            lblEco.Font = new Font("Arial", 12F);
            lblEco.ForeColor = Color.Black;
            lblEco.Location = new Point(0, 18);
            lblEco.Margin = new Padding(0);
            lblEco.Name = "lblEco";
            lblEco.Size = new Size(64, 27);
            lblEco.TabIndex = 0;
            lblEco.Text = "ECO";
            // 
            // txtEco
            // 
            txtEco.BackColor = Color.FromArgb(242, 247, 253);
            txtEco.BorderStyle = BorderStyle.FixedSingle;
            txtEco.Cursor = Cursors.IBeam;
            txtEco.Dock = DockStyle.Bottom;
            txtEco.Font = new Font("Arial", 12F);
            txtEco.ForeColor = SystemColors.MenuText;
            txtEco.Location = new Point(0, 45);
            txtEco.Margin = new Padding(6, 0, 37, 0);
            txtEco.Name = "txtEco";
            txtEco.Size = new Size(360, 35);
            txtEco.TabIndex = 8;
            txtEco.TextAlign = HorizontalAlignment.Center;
            // 
            // panel1
            // 
            panel1.Controls.Add(label2);
            panel1.Controls.Add(txtserie);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(360, 0);
            panel1.Margin = new Padding(0);
            panel1.Name = "panel1";
            panel1.Size = new Size(360, 80);
            panel1.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Bottom;
            label2.Font = new Font("Arial", 12F);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(0, 18);
            label2.Margin = new Padding(0);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(67, 27);
            label2.TabIndex = 1;
            label2.Text = "Serie";
            // 
            // txtserie
            // 
            txtserie.BackColor = Color.FromArgb(242, 247, 253);
            txtserie.BorderStyle = BorderStyle.FixedSingle;
            txtserie.Cursor = Cursors.IBeam;
            txtserie.Dock = DockStyle.Bottom;
            txtserie.Font = new Font("Arial", 12F);
            txtserie.ForeColor = SystemColors.MenuText;
            txtserie.Location = new Point(0, 45);
            txtserie.Margin = new Padding(6, 0, 37, 0);
            txtserie.Name = "txtserie";
            txtserie.Size = new Size(360, 35);
            txtserie.TabIndex = 9;
            txtserie.TextAlign = HorizontalAlignment.Center;
            // 
            // panel2
            // 
            panel2.Controls.Add(label4);
            panel2.Controls.Add(txttipoequipo);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(360, 160);
            panel2.Margin = new Padding(0);
            panel2.Name = "panel2";
            panel2.Size = new Size(360, 80);
            panel2.TabIndex = 28;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Bottom;
            label4.Font = new Font("Arial", 12F);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(0, 18);
            label4.Margin = new Padding(39, 0, 0, 0);
            label4.Name = "label4";
            label4.Size = new Size(88, 27);
            label4.TabIndex = 3;
            label4.Text = "Equipo";
            // 
            // txttipoequipo
            // 
            txttipoequipo.BackColor = Color.FromArgb(242, 247, 253);
            txttipoequipo.BorderStyle = BorderStyle.FixedSingle;
            txttipoequipo.Cursor = Cursors.IBeam;
            txttipoequipo.Dock = DockStyle.Bottom;
            txttipoequipo.Font = new Font("Arial", 12F);
            txttipoequipo.ForeColor = SystemColors.MenuText;
            txttipoequipo.Location = new Point(0, 45);
            txttipoequipo.Margin = new Padding(37, 0, 6, 0);
            txttipoequipo.Name = "txttipoequipo";
            txttipoequipo.Size = new Size(360, 35);
            txttipoequipo.TabIndex = 22;
            txttipoequipo.TextAlign = HorizontalAlignment.Center;
            // 
            // panel6
            // 
            panel6.Controls.Add(label5);
            panel6.Controls.Add(txtpropiedad);
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(720, 0);
            panel6.Margin = new Padding(0);
            panel6.Name = "panel6";
            panel6.Size = new Size(361, 80);
            panel6.TabIndex = 31;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Bottom;
            label5.Font = new Font("Arial", 12F);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(0, 18);
            label5.Margin = new Padding(0);
            label5.Name = "label5";
            label5.Size = new Size(122, 27);
            label5.TabIndex = 4;
            label5.Text = "Propiedad";
            // 
            // txtpropiedad
            // 
            txtpropiedad.BackColor = Color.FromArgb(242, 247, 253);
            txtpropiedad.BorderStyle = BorderStyle.FixedSingle;
            txtpropiedad.Cursor = Cursors.IBeam;
            txtpropiedad.Dock = DockStyle.Bottom;
            txtpropiedad.Font = new Font("Arial", 12F);
            txtpropiedad.ForeColor = SystemColors.MenuText;
            txtpropiedad.Location = new Point(0, 45);
            txtpropiedad.Margin = new Padding(6, 0, 37, 0);
            txtpropiedad.Name = "txtpropiedad";
            txtpropiedad.Size = new Size(361, 35);
            txtpropiedad.TabIndex = 23;
            txtpropiedad.TextAlign = HorizontalAlignment.Center;
            // 
            // panel8
            // 
            panel8.Controls.Add(iconButton1);
            panel8.Controls.Add(iconButton2);
            panel8.Controls.Add(iconButton3);
            panel8.Controls.Add(iconButton4);
            panel8.Dock = DockStyle.Fill;
            panel8.Location = new Point(720, 80);
            panel8.Margin = new Padding(0);
            panel8.Name = "panel8";
            tableLayoutPanel2.SetRowSpan(panel8, 2);
            panel8.Size = new Size(361, 160);
            panel8.TabIndex = 33;
            // 
            // iconButton1
            // 
            iconButton1.BackColor = Color.White;
            iconButton1.Cursor = Cursors.Hand;
            iconButton1.FlatAppearance.BorderSize = 2;
            iconButton1.FlatAppearance.MouseOverBackColor = Color.FromArgb(21, 154, 114);
            iconButton1.FlatStyle = FlatStyle.Flat;
            iconButton1.Font = new Font("Arial", 12F);
            iconButton1.ForeColor = Color.FromArgb(21, 154, 114);
            iconButton1.IconChar = FontAwesome.Sharp.IconChar.Save;
            iconButton1.IconColor = Color.FromArgb(21, 154, 114);
            iconButton1.IconFont = FontAwesome.Sharp.IconFont.Regular;
            iconButton1.IconSize = 35;
            iconButton1.ImageAlign = ContentAlignment.MiddleLeft;
            iconButton1.Location = new Point(0, 0);
            iconButton1.Margin = new Padding(37, 0, 6, 5);
            iconButton1.Name = "iconButton1";
            iconButton1.Size = new Size(200, 70);
            iconButton1.TabIndex = 22;
            iconButton1.Text = "Guardar";
            iconButton1.TextImageRelation = TextImageRelation.ImageBeforeText;
            iconButton1.UseVisualStyleBackColor = true;
            iconButton1.MouseEnter += iconButton1_MouseEnter;
            iconButton1.MouseLeave += iconButton1_MouseLeave;
            // 
            // iconButton2
            // 
            iconButton2.BackColor = Color.White;
            iconButton2.FlatAppearance.BorderSize = 2;
            iconButton2.FlatAppearance.MouseOverBackColor = Color.FromArgb(229, 72, 77);
            iconButton2.FlatStyle = FlatStyle.Flat;
            iconButton2.Font = new Font("Arial", 12F);
            iconButton2.ForeColor = Color.FromArgb(229, 72, 77);
            iconButton2.IconChar = FontAwesome.Sharp.IconChar.Trash;
            iconButton2.IconColor = Color.FromArgb(229, 72, 77);
            iconButton2.IconFont = FontAwesome.Sharp.IconFont.Solid;
            iconButton2.IconSize = 35;
            iconButton2.ImageAlign = ContentAlignment.MiddleLeft;
            iconButton2.Location = new Point(201, 1);
            iconButton2.Margin = new Padding(37, 0, 6, 5);
            iconButton2.Name = "iconButton2";
            iconButton2.Size = new Size(200, 70);
            iconButton2.TabIndex = 23;
            iconButton2.Text = "Eliminar";
            iconButton2.TextImageRelation = TextImageRelation.ImageBeforeText;
            iconButton2.UseVisualStyleBackColor = true;
            // 
            // iconButton3
            // 
            iconButton3.BackColor = Color.White;
            iconButton3.FlatAppearance.BorderSize = 2;
            iconButton3.FlatAppearance.MouseOverBackColor = Color.FromArgb(20, 121, 233);
            iconButton3.FlatStyle = FlatStyle.Flat;
            iconButton3.Font = new Font("Arial", 12F);
            iconButton3.ForeColor = Color.FromArgb(20, 121, 233);
            iconButton3.IconChar = FontAwesome.Sharp.IconChar.Edit;
            iconButton3.IconColor = Color.FromArgb(20, 121, 233);
            iconButton3.IconFont = FontAwesome.Sharp.IconFont.Regular;
            iconButton3.IconSize = 35;
            iconButton3.ImageAlign = ContentAlignment.MiddleLeft;
            iconButton3.Location = new Point(0, 71);
            iconButton3.Margin = new Padding(37, 0, 6, 5);
            iconButton3.Name = "iconButton3";
            iconButton3.Size = new Size(200, 70);
            iconButton3.TabIndex = 24;
            iconButton3.Text = "Editar";
            iconButton3.TextImageRelation = TextImageRelation.ImageBeforeText;
            iconButton3.UseVisualStyleBackColor = true;
            // 
            // iconButton4
            // 
            iconButton4.BackColor = Color.White;
            iconButton4.FlatAppearance.BorderSize = 2;
            iconButton4.FlatAppearance.MouseOverBackColor = Color.FromArgb(102, 117, 138);
            iconButton4.FlatStyle = FlatStyle.Flat;
            iconButton4.Font = new Font("Arial", 12F);
            iconButton4.ForeColor = Color.FromArgb(102, 117, 138);
            iconButton4.IconChar = FontAwesome.Sharp.IconChar.Eraser;
            iconButton4.IconColor = Color.FromArgb(102, 117, 138);
            iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButton4.IconSize = 35;
            iconButton4.ImageAlign = ContentAlignment.MiddleLeft;
            iconButton4.Location = new Point(201, 71);
            iconButton4.Margin = new Padding(37, 0, 6, 5);
            iconButton4.Name = "iconButton4";
            iconButton4.Size = new Size(200, 70);
            iconButton4.TabIndex = 25;
            iconButton4.Text = "Limpiar";
            iconButton4.TextImageRelation = TextImageRelation.ImageBeforeText;
            iconButton4.UseVisualStyleBackColor = true;
            // 
            // panelRedondeado2
            // 
            // tableLayoutPanelkpis
            // 
            tableLayoutPanelkpis.ColumnCount = 1;
            tableLayoutPanelkpis.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanelkpis.Controls.Add(tableLayoutPanel4, 0, 1);
            tableLayoutPanelkpis.Dock = DockStyle.Fill;
            tableLayoutPanelkpis.Location = new Point(10, 10);
            tableLayoutPanelkpis.Margin = new Padding(0);
            tableLayoutPanelkpis.Name = "tableLayoutPanelkpis";
            tableLayoutPanelkpis.RowCount = 2;
            tableLayoutPanelkpis.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanelkpis.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanelkpis.Size = new Size(994, 240);
            tableLayoutPanelkpis.TabIndex = 6;
            // 
            // panelRedondeado5
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Dock = DockStyle.Fill;
            tableLayoutPanel4.Location = new Point(0, 120);
            tableLayoutPanel4.Margin = new Padding(0);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Size = new Size(994, 120);
            tableLayoutPanel4.TabIndex = 0;
            // 
            // 
            panel4.Controls.Add(tableLayoutPanel3);
            panel4.Controls.Add(label11);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Margin = new Padding(0);
            panel4.Name = "panel4";
            panel4.Size = new Size(2124, 93);
            panel4.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.BackColor = Color.Transparent;
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 7.800983F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 92.19902F));
            tableLayoutPanel3.Controls.Add(label10, 0, 0);
            tableLayoutPanel3.Controls.Add(buscarEco, 1, 0);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(0, 0);
            tableLayoutPanel3.Margin = new Padding(0);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Size = new Size(2124, 93);
            tableLayoutPanel3.TabIndex = 22;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.BackColor = Color.FromArgb(0, 15, 255, 255);
            label10.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(21, 29);
            label10.Margin = new Padding(0);
            label10.Name = "label10";
            label10.Size = new Size(122, 34);
            label10.TabIndex = 20;
            label10.Text = "Buscar:";
            // 
            // buscarEco
            // 
            buscarEco.Anchor = AnchorStyles.Left;
            buscarEco.BackColor = Color.FromArgb(242, 247, 253);
            buscarEco.BorderStyle = BorderStyle.FixedSingle;
            buscarEco.Font = new Font("Arial", 12F);
            buscarEco.ForeColor = Color.Black;
            buscarEco.Location = new Point(165, 29);
            buscarEco.Margin = new Padding(0);
            buscarEco.Name = "buscarEco";
            buscarEco.PlaceholderText = "  Busca por Eco...";
            buscarEco.Size = new Size(773, 35);
            buscarEco.TabIndex = 19;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Left;
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            label11.ForeColor = Color.White;
            label11.Location = new Point(841, 25);
            label11.Margin = new Padding(14, 0, 0, 0);
            label11.Name = "label11";
            label11.Size = new Size(250, 34);
            label11.TabIndex = 21;
            label11.Text = "Datos del equipo";
            // 
            // paneltitulo
            // 
            paneltitulo.BackColor = Color.Transparent;
            paneltitulo.Controls.Add(label8);
            paneltitulo.Controls.Add(label9);
            paneltitulo.Dock = DockStyle.Top;
            paneltitulo.Location = new Point(20, 20);
            paneltitulo.Margin = new Padding(0);
            paneltitulo.Name = "paneltitulo";
            paneltitulo.Size = new Size(2124, 68);
            paneltitulo.TabIndex = 0;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Left;
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Arial", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(6, 26, 54);
            label8.Location = new Point(5, 11);
            label8.Margin = new Padding(0);
            label8.Name = "label8";
            label8.Size = new Size(65, 47);
            label8.TabIndex = 19;
            label8.Text = "🏭";
            label8.TextAlign = ContentAlignment.MiddleLeft;
            label8.Click += label8_Click;
            // 
            // btnlimpiar
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Left;
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.FlatStyle = FlatStyle.Flat;
            label9.Font = new Font("Arial", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(6, 26, 54);
            label9.Location = new Point(72, 11);
            label9.Margin = new Padding(0);
            label9.Name = "label9";
            label9.Size = new Size(181, 47);
            label9.TabIndex = 1;
            label9.Text = "Equipos";
            label9.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Guardar
            // 
            // 
            // equipos
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(249, 250, 253);
            ClientSize = new Size(2164, 1410);
            Controls.Add(panelpantalla);
            Margin = new Padding(4, 5, 4, 5);
            Name = "equipos";
            Text = "equipos";
            Load += equipos_Load;
            panelpantalla.ResumeLayout(false);
            paneldatos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)tablaEquipos).EndInit();
            paneldatosxd.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panelEco.ResumeLayout(false);
            panelEco.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel8.ResumeLayout(false);
            tableLayoutPanelkpis.ResumeLayout(false);
            tableLayoutPanel4.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            paneltitulo.ResumeLayout(false);
            paneltitulo.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelpantalla;
        private Panel paneltitulo;
        private ComboBox txttipo_equipo;
        private TextBox txtcliente;
        private TextBox txtproyecto;
        private TextBox txtmodelo;
        private TextBox txtEco;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label lblEco;
        private TextBox buscarEco;
        private Label label9;
        private Label label11;
        private Label label10;
        private TextBox txttipoequipo;
        private TextBox txtpropiedad;
        private Panel paneldatos;
        private DataGridView tablaEquipos;
        private TextBox txtserie;


        private Panel panel4;
        private Panel paneldatosxd;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel2;
        private FontAwesome.Sharp.IconButton iconButton1;
        private FontAwesome.Sharp.IconButton iconButton4;
        private FontAwesome.Sharp.IconButton iconButton3;
        private FontAwesome.Sharp.IconButton iconButton2;
        private TableLayoutPanel tableLayoutPanelkpis;
        private TableLayoutPanel tableLayoutPanel4;

        private TableLayoutPanel tableLayoutPanel3;
        private Label label8;
        private Panel panelEco;
        private Panel panel2;
        private Panel panel1;
        private Panel panel8;
        private Panel panel7;
        private Panel panel6;
        private Panel panel5;
        private Panel panel3;
    }
}